package com.example.gunvault.world;

import com.example.gunvault.GunVault;
import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** One 12 x 12 underground arsenal per successful placed-feature roll.
 * Entire structure fits into one chunk, avoiding concurrent worldgen writes to neighbor chunks.
 * The surface shaft marks the dungeon for discovery; its ladder reaches the armory floor.
 */
public final class VaultFeature extends Feature<NoneFeatureConfiguration> {
    private static final BlockState BRICK = Blocks.DEEPSLATE_BRICKS.defaultBlockState();
    private static final BlockState CRACKED = Blocks.CRACKED_DEEPSLATE_BRICKS.defaultBlockState();
    private static final BlockState AIR = Blocks.AIR.defaultBlockState();
    private static final ResourceLocation CACHE = new ResourceLocation(GunVault.MOD_ID, "chests/arsenal_cache");
    private static final ResourceLocation WEAPON = new ResourceLocation(GunVault.MOD_ID, "chests/arsenal_weapon");

    public VaultFeature(Codec<NoneFeatureConfiguration> codec) { super(codec); }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel level = ctx.level();
        BlockPos base = ctx.origin(); // chunk origin + underground Y (no in_square placement)
        int bx = base.getX() + 2;
        int bz = base.getZ() + 2;
        int y = base.getY();
        int cx = base.getX() + 7;
        int cz = base.getZ() + 7;
        int surface = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, cx, cz);
        if (surface < y + 13 || surface > 140) return false;
        // Do not make an entrance through an ocean/lake or a pre-existing void.
        if (!level.getFluidState(new BlockPos(cx, surface - 1, cz)).isEmpty()) return false;
        for (int dx : new int[]{0, 11}) for (int dz : new int[]{0, 11}) {
            BlockPos p = new BlockPos(bx + dx, y, bz + dz);
            if (level.getBlockState(p).isAir() || !level.getFluidState(p).isEmpty()) return false;
        }

        // Solid floor, walls, roof; clear the interior; varied weathered tiles.
        for (int dx = 0; dx < 12; dx++) for (int dz = 0; dz < 12; dz++) {
            for (int dy = 0; dy <= 6; dy++) {
                boolean wall = dx == 0 || dz == 0 || dx == 11 || dz == 11;
                boolean shell = wall || dy == 0 || dy == 6;
                BlockState material = ctx.random().nextInt(7) == 0 ? CRACKED : BRICK;
                level.setBlock(new BlockPos(bx + dx, y + dy, bz + dz), shell ? material : AIR, 2);
            }
        }

        // Armory interior: metal cages, candles and a hostile guard.
        for (int x : new int[]{bx, bx + 11}) {
            for (int z = bz + 2; z <= bz + 9; z += 3) {
                level.setBlock(new BlockPos(x, y + 3, z), Blocks.SEA_LANTERN.defaultBlockState(), 2);
            }
        }
        for (int z = bz + 3; z < bz + 9; z++) {
            if (z == bz + 6) continue;
            level.setBlock(new BlockPos(bx + 4, y + 1, z), Blocks.IRON_BARS.defaultBlockState(), 2);
        }

        BlockPos spawner = new BlockPos(bx + 9, y + 1, bz + 3);
        level.setBlock(spawner, Blocks.SPAWNER.defaultBlockState(), 2);
        if (level.getBlockEntity(spawner) instanceof SpawnerBlockEntity blockEntity) {
            blockEntity.setEntityId(EntityType.ZOMBIE, ctx.random());
            blockEntity.setChanged();
        }

        // Loot table applied to generated chests; weapon is guaranteed in the locked armory chest.
        putChest(level, ctx, new BlockPos(bx + 2, y + 1, bz + 2), WEAPON);
        putChest(level, ctx, new BlockPos(bx + 9, y + 1, bz + 9), CACHE);

        // Underground-to-surface shaft remains wholly in one chunk; ladder anchored on south wall.
        for (int yy = y + 1; yy <= surface + 1; yy++) {
            for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) {
                int xx = cx + dx, zz = cz + dz;
                boolean center = dx == 0 && dz == 0;
                if (yy <= y + 5) {
                    // Room is hollow; avoid placing shaft wall across the accessible dungeon floor.
                    if (!center) continue;
                }
                level.setBlock(new BlockPos(xx, yy, zz), center ? AIR : BRICK, 2);
            }
            if (yy <= y + 5) {
                // Give the room-level ladder a solid anchor without sealing the room.
                level.setBlock(new BlockPos(cx, yy, cz + 1), BRICK, 2);
            }
            level.setBlock(new BlockPos(cx, yy, cz), Blocks.LADDER.defaultBlockState()
                    .setValue(LadderBlock.FACING, Direction.NORTH), 2);
        }
        // Visible surface beacon and a trapdoor at top of the ladder.
        level.setBlock(new BlockPos(cx, surface + 2, cz), Blocks.OAK_TRAPDOOR.defaultBlockState(), 2);
        for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) {
            if (dx == 0 && dz == 0) continue;
            level.setBlock(new BlockPos(cx + dx, surface + 2, cz + dz), BRICK, 2);
        }
        level.setBlock(new BlockPos(cx + 1, surface + 3, cz), Blocks.TORCH.defaultBlockState(), 2);
        return true;
    }

    private static void putChest(WorldGenLevel world, FeaturePlaceContext<NoneFeatureConfiguration> ctx,
                                 BlockPos pos, ResourceLocation loot) {
        world.setBlock(pos, Blocks.CHEST.defaultBlockState(), 2);
        RandomizableContainerBlockEntity.setLootTable(world, ctx.random(), pos, loot);
    }
}
