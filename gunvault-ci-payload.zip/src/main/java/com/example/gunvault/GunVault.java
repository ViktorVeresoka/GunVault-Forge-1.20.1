package com.example.gunvault;

import com.example.gunvault.craft.MagazineLoadRecipe;
import com.example.gunvault.craft.MagazineUnloadRecipe;
import com.example.gunvault.net.Net;
import com.example.gunvault.world.VaultFeature;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.SimpleCraftingRecipeSerializer;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import com.example.gunvault.item.GlockItem;
import com.example.gunvault.item.MagazineItem;

@Mod(GunVault.MOD_ID)
public final class GunVault {
    public static final String MOD_ID = "gunvault";

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);
    public static final RegistryObject<Item> GLOCK = ITEMS.register("glock17",
            () -> new GlockItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> MAGAZINE = ITEMS.register("glock17_magazine",
            () -> new MagazineItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> AMMO = ITEMS.register("ammo_9mm",
            () -> new Item(new Item.Properties().stacksTo(64)));

    public static final DeferredRegister<RecipeSerializer<?>> RECIPES =
            DeferredRegister.create(ForgeRegistries.RECIPE_SERIALIZERS, MOD_ID);
    public static final RegistryObject<RecipeSerializer<?>> LOAD = RECIPES.register("magazine_load",
            () -> new SimpleCraftingRecipeSerializer<>(MagazineLoadRecipe::new));
    public static final RegistryObject<RecipeSerializer<?>> UNLOAD = RECIPES.register("magazine_unload",
            () -> new SimpleCraftingRecipeSerializer<>(MagazineUnloadRecipe::new));

    public static final DeferredRegister<Feature<?>> FEATURES =
            DeferredRegister.create(Registries.FEATURE, MOD_ID);
    public static final RegistryObject<Feature<?>> VAULT = FEATURES.register("vault_feature",
            () -> new VaultFeature(NoneFeatureConfiguration.CODEC));

    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);
    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("arsenal", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.gunvault"))
                    .icon(() -> new ItemStack(GLOCK.get()))
                    .displayItems((parameters, output) -> {
                        output.accept(GLOCK.get());
                        ItemStack loaded = new ItemStack(MAGAZINE.get());
                        MagazineItem.setRounds(loaded, MagazineItem.CAPACITY);
                        output.accept(loaded);
                        output.accept(MAGAZINE.get());
                        output.accept(AMMO.get());
                    }).build());

    public GunVault() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        RECIPES.register(bus);
        FEATURES.register(bus);
        TABS.register(bus);
        Net.init();
    }
}
