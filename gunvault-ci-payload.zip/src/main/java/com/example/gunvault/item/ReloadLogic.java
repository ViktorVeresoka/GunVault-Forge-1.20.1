package com.example.gunvault.item;

import com.example.gunvault.GunVault;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GunVault.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ReloadLogic {
    private ReloadLogic() { }

    public static void request(ServerPlayer player) {
        ItemStack gun = player.getMainHandItem();
        if (!(gun.getItem() instanceof GlockItem)) return;
        if (player.getCooldowns().isOnCooldown(gun.getItem()) ||
                GlockItem.isReloading(gun, player.level().getGameTime())) return;
        if (bestMagazine(player) < 0) {
            player.displayClientMessage(Component.translatable("message.gunvault.no_magazine"), true);
            return;
        }
        gun.getOrCreateTag().putLong(GlockItem.RELOAD_UNTIL,
                player.level().getGameTime() + GlockItem.RELOAD_TICKS);
        player.getCooldowns().addCooldown(gun.getItem(), GlockItem.RELOAD_TICKS);
        player.level().playSound(null, player.blockPosition(), SoundEvents.ARMOR_EQUIP_IRON,
                SoundSource.PLAYERS, 0.65F, 1.25F);
        player.displayClientMessage(Component.translatable("message.gunvault.reloading"), true);
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.level().isClientSide) return;
        if (!(event.player instanceof ServerPlayer player)) return;
        ItemStack gun = player.getMainHandItem();
        if (!(gun.getItem() instanceof GlockItem) || !gun.hasTag()) return;
        if (!gun.getTag().contains(GlockItem.RELOAD_UNTIL)) return;
        if (gun.getTag().getLong(GlockItem.RELOAD_UNTIL) > player.level().getGameTime()) return;
        gun.getTag().remove(GlockItem.RELOAD_UNTIL);
        int slot = bestMagazine(player);
        if (slot < 0) return;

        // A magazine is swapped, not a pool of loose cartridges.
        ItemStack replacement = player.getInventory().getItem(slot);
        int newRounds = MagazineItem.getRounds(replacement);
        boolean oldInserted = GlockItem.hasMagazine(gun);
        int oldRounds = GlockItem.getRounds(gun);
        player.getInventory().setItem(slot, ItemStack.EMPTY);
        GlockItem.setMagazine(gun, true, newRounds);
        if (oldInserted) {
            ItemStack oldMagazine = new ItemStack(GunVault.MAGAZINE.get());
            MagazineItem.setRounds(oldMagazine, oldRounds);
            // The selected inventory slot became free after removing its magazine.
            player.getInventory().setItem(slot, oldMagazine);
        }
        player.getInventory().setChanged();
        player.level().playSound(null, player.blockPosition(), SoundEvents.CROSSBOW_LOADING_END,
                SoundSource.PLAYERS, 0.7F, 1.15F);
        player.displayClientMessage(Component.translatable("message.gunvault.rounds",
                newRounds, MagazineItem.CAPACITY), true);
    }

    private static int bestMagazine(ServerPlayer player) {
        int best = -1;
        int most = -1;
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack stack = player.getInventory().getItem(i);
            if (stack.is(GunVault.MAGAZINE.get())) {
                int rounds = MagazineItem.getRounds(stack);
                if (rounds > most) { best = i; most = rounds; }
            }
        }
        return best;
    }
}
