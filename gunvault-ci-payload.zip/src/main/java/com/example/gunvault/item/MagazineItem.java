package com.example.gunvault.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import javax.annotation.Nullable;
import java.util.List;

public final class MagazineItem extends Item {
    public static final int CAPACITY = 17;
    private static final String ROUNDS = "Rounds";

    public MagazineItem(Properties properties) { super(properties); }

    public static int getRounds(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return tag == null ? 0 : Math.max(0, Math.min(CAPACITY, tag.getInt(ROUNDS)));
    }

    public static void setRounds(ItemStack stack, int rounds) {
        stack.getOrCreateTag().putInt(ROUNDS, Math.max(0, Math.min(CAPACITY, rounds)));
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.gunvault.magazine", getRounds(stack), CAPACITY)
                .withStyle(ChatFormatting.GOLD));
        tooltip.add(Component.translatable("tooltip.gunvault.magazine_help").withStyle(ChatFormatting.GRAY));
    }

    @Override
    public boolean isBarVisible(ItemStack stack) { return true; }

    @Override
    public int getBarWidth(ItemStack stack) { return Math.round(13f * getRounds(stack) / CAPACITY); }

    @Override
    public int getBarColor(ItemStack stack) { return 0xD4AC47; }
}
