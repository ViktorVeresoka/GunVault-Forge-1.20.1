package com.example.gunvault.item;

import com.example.gunvault.GunVault;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import javax.annotation.Nullable;

import java.util.List;

public final class GlockItem extends Item {
    private static final String INSERTED = "InsertedMagazine";
    private static final String ROUNDS = "Rounds";
    public static final String RELOAD_UNTIL = "ReloadUntil";
    public static final int RELOAD_TICKS = 30; // 1.5 s (TaCZ tactical reload reference)
    public static final int FIRE_INTERVAL_TICKS = 3; // 400 RPM @ 20 TPS
    public static final double RANGE = 48.0;

    public GlockItem(Properties properties) { super(properties); }

    public static boolean hasMagazine(ItemStack gun) {
        return gun.hasTag() && gun.getTag().getBoolean(INSERTED);
    }

    public static int getRounds(ItemStack gun) {
        return gun.hasTag() ? Mth.clamp(gun.getTag().getInt(ROUNDS), 0, MagazineItem.CAPACITY) : 0;
    }

    public static void setMagazine(ItemStack gun, boolean inserted, int rounds) {
        gun.getOrCreateTag().putBoolean(INSERTED, inserted);
        gun.getOrCreateTag().putInt(ROUNDS, inserted ? Mth.clamp(rounds, 0, MagazineItem.CAPACITY) : 0);
    }

    public static boolean isReloading(ItemStack gun, long time) {
        return gun.hasTag() && gun.getTag().contains(RELOAD_UNTIL)
                && gun.getTag().getLong(RELOAD_UNTIL) > time;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, net.minecraft.world.entity.player.Player player,
                                                   InteractionHand hand) {
        ItemStack gun = player.getItemInHand(hand);
        if (hand != InteractionHand.MAIN_HAND) return InteractionResultHolder.pass(gun);
        if (level.isClientSide) return InteractionResultHolder.success(gun);
        if (!(player instanceof ServerPlayer shooter)) return InteractionResultHolder.pass(gun);
        if (player.getCooldowns().isOnCooldown(this)) return InteractionResultHolder.fail(gun);
        if (isReloading(gun, level.getGameTime())) return InteractionResultHolder.fail(gun);

        if (!hasMagazine(gun) || getRounds(gun) == 0) {
            level.playSound(null, player.blockPosition(), SoundEvents.LEVER_CLICK,
                    SoundSource.PLAYERS, 0.42F, 1.65F);
            shooter.displayClientMessage(Component.translatable("message.gunvault.empty"), true);
            player.getCooldowns().addCooldown(this, 8);
            return InteractionResultHolder.fail(gun);
        }

        setMagazine(gun, true, getRounds(gun) - 1);
        player.getCooldowns().addCooldown(this, FIRE_INTERVAL_TICKS);
        level.playSound(null, player.blockPosition(), SoundEvents.CROSSBOW_SHOOT,
                SoundSource.PLAYERS, 0.75F, 1.65F);
        shoot((ServerLevel) level, shooter);
        shooter.displayClientMessage(Component.translatable("message.gunvault.rounds",
                getRounds(gun), MagazineItem.CAPACITY), true);
        return InteractionResultHolder.consume(gun);
    }

    private static void shoot(ServerLevel level, ServerPlayer player) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        double spread = player.isCrouching() ? 0.010 : player.isSprinting() ? 0.038 : 0.020;
        Vec3 direction = look.add(player.getRandom().nextGaussian() * spread,
                player.getRandom().nextGaussian() * spread,
                player.getRandom().nextGaussian() * spread).normalize();
        Vec3 far = eye.add(direction.scale(RANGE));
        BlockHitResult block = level.clip(new ClipContext(eye, far,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        Vec3 end = block.getType() == HitResult.Type.MISS ? far : block.getLocation();
        EntityHitResult target = ProjectileUtil.getEntityHitResult(level, player, eye, end,
                player.getBoundingBox().expandTowards(direction.scale(RANGE)).inflate(1.0),
                e -> e instanceof LivingEntity && e.isPickable() && e != player);
        if (target != null) {
            Entity entity = target.getEntity();
            end = target.getLocation();
            double distance = eye.distanceTo(end);
            float damage = distance <= 18 ? 7F : distance <= 45 ? 5F : 4F;
            boolean headshot = end.y > entity.getY() + entity.getBbHeight() * 0.75;
            if (headshot) damage *= 1.5F;
            entity.hurt(level.damageSources().playerAttack(player), damage);
        }
        Vec3 ray = end.subtract(eye);
        int steps = Mth.clamp((int) (ray.length() / 1.25), 1, 44);
        for (int i = 1; i <= steps; i++) {
            Vec3 pos = eye.add(ray.scale(i / (double) steps));
            level.sendParticles(ParticleTypes.CRIT, pos.x, pos.y, pos.z,
                    1, 0, 0, 0, 0);
        }
        level.sendParticles(ParticleTypes.SMOKE, eye.x + look.x * 0.5,
                eye.y + look.y * 0.5 - 0.1, eye.z + look.z * 0.5, 3, .06, .06, .06, .015);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.gunvault.glock", getRounds(stack), MagazineItem.CAPACITY)
                .withStyle(ChatFormatting.GOLD));
        tooltip.add(Component.translatable("tooltip.gunvault.glock_help").withStyle(ChatFormatting.GRAY));
    }

    @Override
    public boolean isBarVisible(ItemStack stack) { return hasMagazine(stack); }

    @Override
    public int getBarWidth(ItemStack stack) {
        return Math.round(13f * getRounds(stack) / MagazineItem.CAPACITY);
    }

    @Override
    public int getBarColor(ItemStack stack) { return 0xD4AC47; }
}
