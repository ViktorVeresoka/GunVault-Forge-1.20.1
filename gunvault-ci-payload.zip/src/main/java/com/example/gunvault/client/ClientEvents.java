package com.example.gunvault.client;

import com.example.gunvault.GunVault;
import com.example.gunvault.net.Net;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

public final class ClientEvents {
    private static final KeyMapping RELOAD = new KeyMapping("key.gunvault.reload",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R, "key.categories.gunvault");

    @Mod.EventBusSubscriber(modid = GunVault.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class Registration {
        @SubscribeEvent
        public static void register(RegisterKeyMappingsEvent event) { event.register(RELOAD); }
    }

    @Mod.EventBusSubscriber(modid = GunVault.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
    public static final class Input {
        @SubscribeEvent
        public static void tick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END || Minecraft.getInstance().player == null) return;
            while (RELOAD.consumeClick()) Net.reload();
        }
    }
}
