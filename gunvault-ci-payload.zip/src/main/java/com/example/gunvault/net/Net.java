package com.example.gunvault.net;

import com.example.gunvault.GunVault;
import com.example.gunvault.item.ReloadLogic;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;
import java.util.function.Supplier;

public final class Net {
    private static final String VERSION = "1";
    private static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(GunVault.MOD_ID, "main"),
            () -> VERSION, VERSION::equals, VERSION::equals);
    private Net() { }

    public static void init() {
        CHANNEL.registerMessage(0, ReloadPacket.class,
                (p, buf) -> { }, buf -> new ReloadPacket(), Net::handle);
    }

    public static void reload() { CHANNEL.sendToServer(new ReloadPacket()); }

    private static void handle(ReloadPacket packet, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            ServerPlayer sender = context.getSender();
            if (sender != null) ReloadLogic.request(sender);
        });
        context.setPacketHandled(true);
    }

    private record ReloadPacket() { }
}
