package com.example.gunvault.craft;

import com.example.gunvault.GunVault;
import com.example.gunvault.item.MagazineItem;
import net.minecraft.core.RegistryAccess;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingBookCategory;
import net.minecraft.world.item.crafting.CustomRecipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.Level;

public final class MagazineLoadRecipe extends CustomRecipe {
    public MagazineLoadRecipe(ResourceLocation id, CraftingBookCategory category) { super(id, category); }

    @Override
    public boolean matches(CraftingContainer grid, Level level) { return inspect(grid) != null; }

    @Override
    public ItemStack assemble(CraftingContainer grid, RegistryAccess access) {
        Data data = inspect(grid);
        if (data == null) return ItemStack.EMPTY;
        ItemStack result = data.magazine.copy();
        result.setCount(1);
        MagazineItem.setRounds(result, data.newRounds);
        return result;
    }

    private static Data inspect(CraftingContainer grid) {
        ItemStack magazine = ItemStack.EMPTY;
        int bullets = 0;
        for (int i = 0; i < grid.getContainerSize(); i++) {
            ItemStack stack = grid.getItem(i);
            if (stack.isEmpty()) continue;
            if (stack.is(GunVault.MAGAZINE.get()) && magazine.isEmpty()) magazine = stack;
            else if (stack.is(GunVault.AMMO.get())) bullets += stack.getCount();
            else return null;
        }
        if (magazine.isEmpty() || bullets == 0 || bullets > MagazineItem.CAPACITY) return null;
        int newRounds = MagazineItem.getRounds(magazine) + bullets;
        return newRounds > MagazineItem.CAPACITY ? null : new Data(magazine, newRounds);
    }

    private record Data(ItemStack magazine, int newRounds) { }

    @Override
    public boolean canCraftInDimensions(int w, int h) { return w * h >= 2; }

    @Override
    public RecipeSerializer<?> getSerializer() { return GunVault.LOAD.get(); }
}
