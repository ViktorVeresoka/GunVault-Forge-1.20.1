package com.example.gunvault.craft;

import com.example.gunvault.GunVault;
import com.example.gunvault.item.MagazineItem;
import net.minecraft.core.NonNullList;
import net.minecraft.core.RegistryAccess;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingBookCategory;
import net.minecraft.world.item.crafting.CustomRecipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.Level;

public final class MagazineUnloadRecipe extends CustomRecipe {
    public MagazineUnloadRecipe(ResourceLocation id, CraftingBookCategory category) { super(id, category); }

    private static int indexOfMagazine(CraftingContainer grid) {
        int index = -1;
        for (int i = 0; i < grid.getContainerSize(); i++) {
            ItemStack stack = grid.getItem(i);
            if (stack.isEmpty()) continue;
            if (!stack.is(GunVault.MAGAZINE.get()) || index >= 0 || MagazineItem.getRounds(stack) <= 0)
                return -1;
            index = i;
        }
        return index;
    }

    @Override
    public boolean matches(CraftingContainer grid, Level level) { return indexOfMagazine(grid) >= 0; }

    @Override
    public ItemStack assemble(CraftingContainer grid, RegistryAccess access) {
        return matches(grid, null) ? new ItemStack(GunVault.AMMO.get()) : ItemStack.EMPTY;
    }

    @Override
    public NonNullList<ItemStack> getRemainingItems(CraftingContainer grid) {
        NonNullList<ItemStack> result = NonNullList.withSize(grid.getContainerSize(), ItemStack.EMPTY);
        int index = indexOfMagazine(grid);
        if (index >= 0) {
            ItemStack magazine = grid.getItem(index).copy();
            MagazineItem.setRounds(magazine, MagazineItem.getRounds(magazine) - 1);
            result.set(index, magazine);
        }
        return result;
    }

    @Override
    public boolean canCraftInDimensions(int w, int h) { return w * h >= 1; }

    @Override
    public RecipeSerializer<?> getSerializer() { return GunVault.UNLOAD.get(); }
}
