package com.example.gunvault.craft;

import com.example.gunvault.GunVault;
import net.minecraft.world.inventory.CraftingContainer;
import com.example.gunvault.item.MagazineItem;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Vanilla crafting decreases each occupied slot by just 1, irrespective of stack size.
 * The loaded result accounts for ALL 9mm rounds supplied in each slot, so before
 * vanilla's final decrement this handler consumes (stackSize - 1) additional rounds.
 * Note: this hook is deliberately restricted to the magazine-output custom recipe.
 */
@Mod.EventBusSubscriber(modid = GunVault.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class CraftingHooks {
    private CraftingHooks() { }

    @SubscribeEvent
    public static void crafted(PlayerEvent.ItemCraftedEvent event) {
        if (event.getEntity().level().isClientSide) return;
        if (!event.getCrafting().is(GunVault.MAGAZINE.get())) return;
        if (!(event.getInventory() instanceof CraftingContainer grid)) return;
        int magazines = 0;
        int ammo = 0;
        ItemStack inputMag = ItemStack.EMPTY;
        for (int i = 0; i < grid.getContainerSize(); i++) {
            ItemStack input = grid.getItem(i);
            if (input.isEmpty()) continue;
            if (input.is(GunVault.MAGAZINE.get())) { magazines++; inputMag = input; }
            else if (input.is(GunVault.AMMO.get())) ammo += input.getCount();
            else return;
        }
        if (magazines != 1 || ammo <= 0 ||
                MagazineItem.getRounds(inputMag) + ammo != MagazineItem.getRounds(event.getCrafting())) return;
        for (int i = 0; i < grid.getContainerSize(); i++) {
            ItemStack input = grid.getItem(i);
            if (input.is(GunVault.AMMO.get()) && input.getCount() > 1) {
                // Do not empty the slot completely; vanilla ResultSlot will take the last item.
                input.shrink(input.getCount() - 1);
            }
        }
    }
}
