"""Offline packaging/configuration checks; NOT a Minecraft runtime test."""
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
resource = root / 'src/main/resources'
for p in resource.rglob('*.json'):
    json.loads(p.read_text(encoding='utf8'))
assert (resource / 'data/gunvault/recipes/load_magazine.json').exists()
assert (resource / 'data/gunvault/recipes/unload_magazine.json').exists()
assert not any('glock17' in x.stem for x in (resource / 'data/gunvault/recipes').rglob('*.json'))

weapon = json.loads((resource / 'data/gunvault/loot_tables/chests/arsenal_weapon.json').read_text())
assert any(any(e.get('name') == 'gunvault:glock17' for e in pool['entries']) for pool in weapon['pools'])
features = json.loads((resource / 'data/gunvault/worldgen/configured_feature/vault.json').read_text())
assert features['type'] == 'gunvault:vault_feature'
placement = json.loads((resource / 'data/gunvault/worldgen/placed_feature/vault.json').read_text())
assert placement['feature'] == 'gunvault:vault'
modifier = json.loads((resource / 'data/gunvault/forge/biome_modifier/vaults.json').read_text())
assert modifier['biomes'] == '#minecraft:is_overworld'

# Conservation model for one magazine crafting operation using pre-vanilla stack shrink.
for before in range(18):
    for supplied in range(1, 65):
        valid = before + supplied <= 17
        if valid:
            new_rounds = before + supplied
            remaining_supplied = supplied - (supplied - 1) - 1
            assert remaining_supplied == 0
            assert new_rounds - before == supplied
        else:
            assert before + supplied > 17

for before in range(1, 18):
    after = before - 1
    assert after >= 0 and (after + 1) == before

print('PASS: JSON, no gun recipe, guaranteed gun loot, feature links, cartridge-conservation model')
print('IMPORTANT: does not compile Java or test Forge 1.20.1 in-game behavior')
